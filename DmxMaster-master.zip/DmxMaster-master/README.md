DmxSimple
---------

Simple DMX master library for Arduino (TM)


Originally written by Tinker.it Ltd 


DmxSimple v3 release:
  Changes from v2 to v3:
    Optimised interrupt routine now supports serial baud rates up to 115200.
    DMX output pin can be changed with the DmxMaster.usePin() function.
    Automatic support for future clock rates and pin mappings.
    Syntax highlighting in Arduino editor fixed.
    More comments added to FadeUp and SerialToDmx examples
    FadeUp example now demonstrates all DmxMaster functions.
    Release notes file added. (For older revisions, see SVN log on Google Code)
